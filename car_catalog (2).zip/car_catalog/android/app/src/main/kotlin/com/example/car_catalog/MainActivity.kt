package com.example.car_catalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
